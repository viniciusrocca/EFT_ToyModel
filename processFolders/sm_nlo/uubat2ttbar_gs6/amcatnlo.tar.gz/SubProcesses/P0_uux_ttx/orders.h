#define __amp_split_size 2
#define __amp_split_size_born 1
